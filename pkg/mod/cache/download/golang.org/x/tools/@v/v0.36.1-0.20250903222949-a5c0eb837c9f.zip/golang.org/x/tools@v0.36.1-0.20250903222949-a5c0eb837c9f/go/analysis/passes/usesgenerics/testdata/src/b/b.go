// want package:`features{typeSet}`

package b

type Constraint interface {
	~int | string
}
